import React from "react";

const ServiceCard: React.FC = () => {
  return <div>ServiceCard</div>;
};

export default ServiceCard;
