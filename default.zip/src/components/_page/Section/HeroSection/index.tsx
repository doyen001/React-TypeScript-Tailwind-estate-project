import React from "react";

const HeroSection: React.FC = () => {
  return <div className='text-red-500 text-center text-lg'>HeroSectio</div>;
};

export default HeroSection;
