import React from "react";

const ServceSection: React.FC = () => {
  return <div>ServceSection</div>;
};

export default ServceSection;
