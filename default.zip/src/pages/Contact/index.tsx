import React from "react";
import ContactPage from "../../components/_page/Contact";

const Contact: React.FC = () => {
  return <ContactPage />;
};

export default Contact;
