import React from "react";
import styles from "./styles.module.scss";

const Header: React.FC = () => {
  return <div className={styles.wrapper}>Header</div>;
};

export default Header;
