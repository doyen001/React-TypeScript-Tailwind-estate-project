export interface IUser {
  firstName?: string;
  lastName?: string;
  brithday?: string;
  age?: number;
}

export interface IUserData {
  firstName: string;
  lastName: string;
  brithday: string;
  age: number;
}
